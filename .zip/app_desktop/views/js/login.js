document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("error-message");
  errorMsg.textContent = "";

  try {
    const res = await fetch("http://127.0.0.1:8000/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    if (res.ok) {
      const data = await res.json();

      // Guardar en localStorage (fallback navegador)
      localStorage.setItem("token", data.access_token);
      localStorage.setItem("role", data.role);
      localStorage.setItem("user_id", data.user_id);

      console.log("✅ Login correcto:", data);

      // Si está en PyQt
      if (window.qtBridgeObj) {
        console.log("📡 Enviando datos al Bridge PyQt...");
        window.qtBridgeObj.onLoginSuccess(data.access_token, data.role, data.user_id);
      } else {
        console.warn("⚠️ PyQt Bridge no detectado, modo navegador");
        redirectByRole(data.role);
      }
    } else {
      const err = await res.json();
      errorMsg.textContent = err.detail || "Credenciales incorrectas";
    }
  } catch (error) {
    console.error("Error de conexión:", error);
    errorMsg.textContent = "⚠️ Error de conexión con el servidor";
  }
});

function redirectByRole(role) {
  if (role === "admin") {
    window.location.href = "../html/adminPacientes.html";
  } else if (role === "psychologist") {
    window.location.href = "../html/psicoPacientes.html";
  } else {
    window.location.href = "../html/pacieCalendario.html";
  }
}
