import json
import os
import sys
from PyQt5.QtCore import QUrl, QObject, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWebChannel import QWebChannel


class Bridge(QObject):
    loginSuccess = pyqtSignal(str, str, int)

    @pyqtSlot(str, str, int)
    def onLoginSuccess(self, token, role, user_id):
        print(f"🧩 Bridge recibido: role={role}, user_id={user_id}")
        script = f"""
            localStorage.setItem('token', '{token}');
            localStorage.setItem('role', '{role}');
            localStorage.setItem('user_id', '{user_id}');
        """
        self.parent().web_view.page().runJavaScript(script)
        QMessageBox.information(None, "Login exitoso", f"Rol: {role}\nID: {user_id}")
        self.loginSuccess.emit(token, role, user_id)


class WebWindow(QMainWindow):
    def __init__(self, html_file="login.html"):
        super().__init__()
        self.setWindowTitle("EMOTIA")
        self.setGeometry(200, 100, 1280, 720)

        self.web_view = QWebEngineView(self)
        self.bridge = Bridge()
        self.bridge.setParent(self)

        self.channel = QWebChannel()
        self.channel.registerObject("qtBridgeObj", self.bridge)
        self.web_view.page().setWebChannel(self.channel)

        html_path = os.path.join(os.path.dirname(__file__), "views", "html", html_file)
        self.web_view.load(QUrl.fromLocalFile(os.path.abspath(html_path)))
        self.setCentralWidget(self.web_view)

        self.bridge.loginSuccess.connect(self.load_dashboard)
        self.web_view.page().javaScriptConsoleMessage = self.handle_js_console

        # 🔹 Verifica si hay sesión guardada
        self.web_view.page().runJavaScript("""
            const role = localStorage.getItem('role');
            const user_id = localStorage.getItem('user_id');
            if (role && user_id) {
                window.location.href = role === 'admin'
                    ? '../html/adminPacientes.html'
                    : role === 'psychologist'
                        ? '../html/psicoPacientes.html'
                        : '../html/pacieCalendario.html';
            }
        """)

    def handle_js_console(self, level, msg, line, sourceID):
        print(f"[JS] {msg}")

    def load_dashboard(self, token, role, user_id):
        if role == "admin":
            html = "adminPacientes.html"
        elif role == "psychologist":
            html = "psicoPacientes.html"
        elif role == "patient":
            html = "pacieCalendario.html"
        else:
            html = "login.html"

        html_path = os.path.join(os.path.dirname(__file__), "views", "html", html)
        self.web_view.load(QUrl.fromLocalFile(os.path.abspath(html_path)))
        QMessageBox.information(self, "Login exitoso", f"Bienvenido {role}")

    def closeEvent(self, event):
        """🧹 Limpia sesión al cerrar la app"""
        print("🧹 Cerrando aplicación y limpiando sesión...")
        self.web_view.page().runJavaScript("""
            localStorage.removeItem('token');
            localStorage.removeItem('role');
            localStorage.removeItem('user_id');
        """)
        event.accept()

class EmotiaApp(QApplication):
    def __init__(self, args):
        super().__init__(args)
        self.window = WebWindow("login.html")
        self.window.show()


if __name__ == "__main__":
    app = EmotiaApp(sys.argv)
    sys.exit(app.exec_())
